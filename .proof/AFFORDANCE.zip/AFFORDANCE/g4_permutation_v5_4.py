"""
G4 permutation control for v5.4.

For each trained B/C/D seed:
  - Sample episodes with (c_u, c_w, c_v) as usual.
  - Permute c-channels across episodes (breaking c <-> z pairing).
  - Retrain/refreeze model, measure own-bit bacc on normal vs permuted channels.
  - Criterion: permuted own-bit bacc <= 0.55.
"""
import numpy as np
import torch
import argparse, json
from collections import defaultdict
from v5_4_train import EnvV54, PolicyV54, train_variant, bacc, AUX_DIM, SIGMA_C

def eval_permuted(model, variant, seed, n_ep=2000, permute_c=False):
    env = EnvV54(seed=seed * 1000 + 7777)
    has_head = model.has_head
    rng = np.random.RandomState(seed + 12345)
    model.eval()

    # collect raw episodes
    episodes = []
    with torch.no_grad():
        for _ in range(n_ep):
            s = env.reset()
            episodes.append(s)

    # permute c channels
    if permute_c:
        perm = rng.permutation(len(episodes))
        for i, s in enumerate(episodes):
            j = perm[i]
            s["c_u"] = episodes[j]["c_u"]
            s["c_w"] = episodes[j]["c_w"]
            s["c_v"] = episodes[j]["c_v"]

    # roll out with frozen model
    decisions = []
    with torch.no_grad():
        for s in episodes:
            o_t = torch.tensor(s["o_task"], dtype=torch.float32).unsqueeze(0)
            c_t = torch.tensor([[s["c_u"], s["c_w"], s["c_v"]]], dtype=torch.float32)
            if has_head:
                aux = model.head_forward(o_t, c_t).squeeze(0)
            else:
                aux = torch.zeros(AUX_DIM)
            logits, _ = model(o_t, aux)
            a = int(logits.squeeze(0).argmax())
            decisions.append({"a": a, "s": s})

    if variant == "B":
        y = np.array([d["s"]["z_u"] for d in decisions])
        pred = np.array([1 if d["a"] > 0 else 0 for d in decisions])
        return bacc(y, pred)
    else:
        correct = np.array([0 if d["s"]["z_u"] == 0 else 1 + d["s"]["z_w"] for d in decisions])
        pred = np.array([d["a"] for d in decisions])
        return float((pred == correct).mean())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variants", type=str, default="B,C,D")
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--steps", type=int, default=200_000)
    ap.add_argument("--out", type=str, default="v5_4_g4.json")
    args = ap.parse_args()

    variants = args.variants.split(",")
    print("=" * 70)
    print("G4 permutation control v5.4")
    print("=" * 70)

    agg = defaultdict(lambda: {"normal": [], "perm": []})

    for variant in variants:
        print(f"\n--- {variant} ---")
        for seed in range(args.seeds):
            model = train_variant(variant, seed=seed, n_steps=args.steps)
            normal = eval_permuted(model, variant, seed, permute_c=False)
            perm = eval_permuted(model, variant, seed, permute_c=True)
            agg[variant]["normal"].append(normal)
            agg[variant]["perm"].append(perm)
            print(f"  seed={seed}: normal={normal:.4f} perm={perm:.4f} drop={normal-perm:+.4f}")

    print("\n" + "=" * 70)
    print("AGGREGATE")
    print("=" * 70)
    for v in variants:
        n = np.array(agg[v]["normal"]); p = np.array(agg[v]["perm"])
        print(f"  {v}: normal median={np.median(n):.4f}  perm median={np.median(p):.4f}  "
              f"perm max={max(p):.4f}  PASS={max(p)<=0.55}")

    with open(args.out, "w") as f:
        json.dump({v: {k: list(vals) for k, vals in agg[v].items()} for v in variants},
                  f, indent=2, default=str)


if __name__ == "__main__":
    main()