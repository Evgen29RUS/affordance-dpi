"""
STEP A' v5.4 — gates for asymmetric two-lock task.

Task: u = capability (can I act?), w = target (what to do).
Correct action: 0 if u=0 else 1+w.

Gates:
  A'-0 balance
  A'-1 own channel (c_u -> z_u, c_w -> z_w) >= 0.95
  A'-2 cross-channel <= 0.55
  A'-3 o_task -> z <= 0.60
  A'-4 c_v -> z <= 0.55
  A'-5 gap (own - o_task) >= 0.30
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

N = 10000
SIGMA_C = 0.005


def train_probe(X, y, kind="mlp", seed=0):
    torch.manual_seed(seed)
    Xt = torch.tensor(X, dtype=torch.float32)
    yt = torch.tensor(y, dtype=torch.long)
    n = len(Xt)
    idx = torch.randperm(n)
    tr, va = idx[: n * 7 // 10], idx[n * 7 // 10 :]
    if kind == "lin":
        model = nn.Linear(X.shape[1], 2)
    else:
        model = nn.Sequential(nn.Linear(X.shape[1], 32), nn.ReLU(),
                              nn.Linear(32, 32), nn.ReLU(), nn.Linear(32, 2))
    opt = torch.optim.Adam(model.parameters(), lr=3e-3)
    for _ in range(500):
        loss = F.cross_entropy(model(Xt[tr]), yt[tr])
        opt.zero_grad(); loss.backward(); opt.step()
    model.eval()
    with torch.no_grad():
        pred = model(Xt[va]).argmax(dim=-1)
        acc = (pred == yt[va]).float().mean().item()
    return acc


def main():
    rng = np.random.RandomState(42)
    z_u = rng.randint(2, size=N)
    z_w = rng.randint(2, size=N)
    z_v = rng.randint(2, size=N)
    c_u = z_u + rng.normal(0, SIGMA_C, N)
    c_w = z_w + rng.normal(0, SIGMA_C, N)
    c_v = z_v + rng.normal(0, SIGMA_C, N)
    o_task = rng.uniform(-1, 1, size=(N, 4))

    print("=" * 70)
    print(f"STEP A' v5.4 — asymmetric two-lock  SIGMA_C={SIGMA_C}")
    print("=" * 70)
    print(f"\nA'-0  P(z_u=1)={z_u.mean():.4f}  P(z_w=1)={z_w.mean():.4f}  P(z_v=1)={z_v.mean():.4f}")

    results = {}
    for name, X, y, seed in [
        ("c_u->z_u", c_u.reshape(-1, 1), z_u, 1),
        ("c_w->z_w", c_w.reshape(-1, 1), z_w, 2),
        ("c_u->z_w", c_u.reshape(-1, 1), z_w, 3),
        ("c_w->z_u", c_w.reshape(-1, 1), z_u, 4),
        ("o_task->z_u", o_task, z_u, 5),
        ("o_task->z_w", o_task, z_w, 6),
        ("c_v->z_u", c_v.reshape(-1, 1), z_u, 7),
        ("c_v->z_w", c_v.reshape(-1, 1), z_w, 8),
    ]:
        lin = train_probe(X, y, "lin", seed)
        mlp = train_probe(X, y, "mlp", seed)
        results[name] = (lin, mlp)
        print(f"  {name}: lin={lin:.4f} mlp={mlp:.4f}")

    own_u = max(results["c_u->z_u"]); own_w = max(results["c_w->z_w"])
    hist_u = max(results["o_task->z_u"]); hist_w = max(results["o_task->z_w"])
    gap_u = own_u - hist_u
    gap_w = own_w - hist_w

    checks = {
        "A'-0": abs(z_u.mean()-0.5)<0.05 and abs(z_w.mean()-0.5)<0.05,
        "A'-1": own_u >= 0.95 and own_w >= 0.95,
        "A'-2": max(results["c_u->z_w"]) <= 0.55 and max(results["c_w->z_u"]) <= 0.55,
        "A'-3": hist_u <= 0.60 and hist_w <= 0.60,
        "A'-4": max(results["c_v->z_u"]) <= 0.55 and max(results["c_v->z_w"]) <= 0.55,
        "A'-5": gap_u >= 0.30 and gap_w >= 0.30,
    }

    print(f"\nA'-5  gap_u={gap_u:.4f}  gap_w={gap_w:.4f}")
    print("\nGATES:")
    for k, v in checks.items():
        print(f"  {k}: {'PASS' if v else 'FAIL'}")
    print(f"\n  ALL PASS: {all(checks.values())}")


if __name__ == "__main__":
    main()