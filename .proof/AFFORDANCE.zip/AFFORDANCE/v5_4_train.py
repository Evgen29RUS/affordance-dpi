"""
v5.4 PPO — asymmetric two-lock task.

6 variants:
  A: no aux (aux = 0)
  B: aux = head output, target = z_u (capability bit)
  C: aux = head output, target = z_w (target bit)
  D: aux = head output, target = z_v (irrelevant)
  E: aux = 0 (same as A but with slot)
  H: aux = head output, target = N(0,1) noise

Preregistered expectation:
  return(B) ≈ +0.5
  return(C) ≈ return(A) ≈ return(D) ≈ return(E) ≈ return(H) ≈ 0.0
  R1: B - D > 0 (p < 0.0125, Wilcoxon)
  R2: B - C > 0 (p < 0.0125)  -- the asymmetry test
  TOST: |B - C| < 0.15 fails, confirming B > C is significant
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical
import argparse, json
from collections import defaultdict
from scipy.stats import wilcoxon

SIGMA_C = 0.005
N_ACTIONS = 3
O_TASK_DIM = 4
AUX_DIM = 1


def correct_action(z_u, z_w):
    return 0 if z_u == 0 else 1 + z_w


class EnvV54:
    def __init__(self, seed=0):
        self.rng = np.random.RandomState(seed)
    def reset(self):
        z_u = int(self.rng.randint(2)); z_w = int(self.rng.randint(2)); z_v = int(self.rng.randint(2))
        c_u = z_u + self.rng.normal(0, SIGMA_C)
        c_w = z_w + self.rng.normal(0, SIGMA_C)
        c_v = z_v + self.rng.normal(0, SIGMA_C)
        o_task = self.rng.uniform(-1, 1, size=O_TASK_DIM).astype(np.float32)
        return {"z_u": z_u, "z_w": z_w, "z_v": z_v,
                "c_u": c_u, "c_w": c_w, "c_v": c_v, "o_task": o_task}
    def step(self, action, state):
        target = correct_action(state["z_u"], state["z_w"])
        return (1.0 if action == target else -1.0), True


class PolicyV54(nn.Module):
    def __init__(self, variant, hidden=64):
        super().__init__()
        self.variant = variant
        self.has_head = variant in ("B", "C", "D", "H")
        self.actor = nn.Sequential(
            nn.Linear(O_TASK_DIM + AUX_DIM, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, N_ACTIONS))
        self.critic = nn.Sequential(
            nn.Linear(O_TASK_DIM + AUX_DIM, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, 1))
        if self.has_head:
            self.head = nn.Sequential(
                nn.Linear(O_TASK_DIM + 3, hidden), nn.ReLU(),
                nn.Linear(hidden, hidden), nn.ReLU(),
                nn.Linear(hidden, AUX_DIM))
    def forward(self, o_task, aux):
        if aux.ndim == 1: aux = aux.unsqueeze(0)
        inp = torch.cat([o_task, aux], dim=-1)
        return self.actor(inp), self.critic(inp).squeeze(-1)
    def head_forward(self, o_task, c):
        inp = torch.cat([o_task, c], dim=-1)
        return self.head(inp)


def train_variant(variant, seed, n_steps=200_000, rollout_T=128,
                  lr=3e-4, clip=0.2, epochs=4, lam_aux=30.0,
                  ent_coef=0.01, vf_coef=0.5, log_every=400):
    torch.manual_seed(seed); np.random.seed(seed)
    env = EnvV54(seed=seed * 1000 + 17)
    model = PolicyV54(variant)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    n_upd = n_steps // rollout_T
    has_head = model.has_head
    rets = []

    for upd in range(n_upd):
        obs = np.zeros((rollout_T, O_TASK_DIM), dtype=np.float32)
        cs = np.zeros((rollout_T, 3), dtype=np.float32)
        auxs = np.zeros((rollout_T, AUX_DIM), dtype=np.float32)
        tgts = np.zeros((rollout_T, AUX_DIM), dtype=np.float32)
        acts = np.zeros(rollout_T, dtype=np.int64)
        logps = np.zeros(rollout_T, dtype=np.float32)
        rews = np.zeros(rollout_T, dtype=np.float32)
        vals = np.zeros(rollout_T, dtype=np.float32)
        rng_local = np.random.RandomState(seed * 10000 + upd)

        model.eval()
        with torch.no_grad():
            for t in range(rollout_T):
                s = env.reset()
                o_t = torch.tensor(s["o_task"], dtype=torch.float32).unsqueeze(0)
                c_t = torch.tensor([[s["c_u"], s["c_w"], s["c_v"]]], dtype=torch.float32)
                if has_head:
                    aux = model.head_forward(o_t, c_t).squeeze(0)
                    if variant == "B": tgt = torch.tensor([float(s["z_u"])])
                    elif variant == "C": tgt = torch.tensor([float(s["z_w"])])
                    elif variant == "D": tgt = torch.tensor([float(s["z_v"])])
                    elif variant == "H": tgt = torch.tensor(rng_local.normal(0, 1, AUX_DIM), dtype=torch.float32)
                else:
                    aux = torch.zeros(AUX_DIM); tgt = torch.zeros(AUX_DIM)
                logits, v = model(o_t, aux)
                dist = Categorical(logits=logits)
                a = dist.sample()
                rew, _ = env.step(a.item(), s)
                obs[t] = s["o_task"]; cs[t] = c_t[0].numpy()
                auxs[t] = aux.numpy() if hasattr(aux, "numpy") else np.array([float(aux)])
                tgts[t] = tgt.numpy()
                acts[t] = a.item(); logps[t] = dist.log_prob(a).item()
                rews[t] = rew; vals[t] = v.item()
                rets.append(rew)

        adv = rews - vals
        adv = (adv - adv.mean()) / (adv.std() + 1e-8)

        obs_t = torch.tensor(obs); aux_t = torch.tensor(auxs)
        act_t = torch.tensor(acts); logp_old = torch.tensor(logps)
        adv_t = torch.tensor(adv, dtype=torch.float32)
        ret_t = torch.tensor(rews, dtype=torch.float32)
        c_t = torch.tensor(cs); tgt_t = torch.tensor(tgts)

        model.train()
        for _ in range(epochs):
            logits, val = model(obs_t, aux_t)
            dist = Categorical(logits=logits)
            logp_new = dist.log_prob(act_t)
            ratio = torch.exp(logp_new - logp_old)
            pg1 = ratio * adv_t
            pg2 = torch.clamp(ratio, 1 - clip, 1 + clip) * adv_t
            pol_loss = -torch.min(pg1, pg2).mean()
            val_loss = F.mse_loss(val, ret_t)
            ent = dist.entropy().mean()
            loss = pol_loss + vf_coef * val_loss - ent_coef * ent
            if has_head:
                aux_pred = model.head_forward(obs_t, c_t)
                aux_loss = F.mse_loss(aux_pred, tgt_t)
                loss = loss + lam_aux * aux_loss
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)
            opt.step()

        if (upd + 1) % log_every == 0:
            print(f"    [{variant}] {upd+1}/{n_upd}  ret={np.mean(rets[-500:]):+.4f}")

    return model


def bacc(y, p):
    accs = []
    for c in [0, 1]:
        m = y == c
        if m.sum() > 0:
            accs.append((p[m] == y[m]).mean())
    return float(np.mean(accs))


def eval_variant(model, variant, seed, n_ep=2000):
    env = EnvV54(seed=seed * 1000 + 999)
    has_head = model.has_head
    episodes = []
    model.eval()
    with torch.no_grad():
        for _ in range(n_ep):
            s = env.reset()
            o_t = torch.tensor(s["o_task"], dtype=torch.float32).unsqueeze(0)
            c_t = torch.tensor([[s["c_u"], s["c_w"], s["c_v"]]], dtype=torch.float32)
            if has_head:
                aux = model.head_forward(o_t, c_t).squeeze(0)
            else:
                aux = torch.zeros(AUX_DIM)
            logits, _ = model(o_t, aux)
            logits = logits.squeeze(0)
            p = torch.softmax(logits, dim=-1).numpy()
            a = int(p.argmax())
            rew, _ = env.step(a, s)
            episodes.append({"s": s, "aux": float(aux) if aux.numel() == 1 else aux.tolist(),
                             "a": a, "rew": rew, "logits": logits.numpy(), "p": p})

    ret = float(np.mean([e["rew"] for e in episodes]))

    # Own-bit accuracy
    if variant == "B":
        y = np.array([e["s"]["z_u"] for e in episodes])
        pred = np.array([1 if e["a"] > 0 else 0 for e in episodes])
        own_acc = bacc(y, pred)
    else:
        correct = np.array([correct_action(e["s"]["z_u"], e["s"]["z_w"]) for e in episodes])
        a_arr = np.array([e["a"] for e in episodes])
        own_acc = float((a_arr == correct).mean())

    # aux accuracy
    aux_acc = None
    if has_head:
        aux_vals = np.array([e["aux"] for e in episodes])
        if variant == "B": y = np.array([e["s"]["z_u"] for e in episodes])
        elif variant == "C": y = np.array([e["s"]["z_w"] for e in episodes])
        elif variant == "D": y = np.array([e["s"]["z_v"] for e in episodes])
        else: y = None
        if y is not None:
            pred = (aux_vals > 0.5).astype(int)
            aux_acc = bacc(y, pred)

    # TV shuffle (matched: shuffle aux across episodes with same o_task distribution)
    tv_mean = 0.0
    if has_head:
        aux_vals = np.array([e["aux"] for e in episodes])
        perm = np.random.RandomState(12345).permutation(len(episodes))
        aux_shuf = aux_vals[perm]
        tvs = []
        flips = 0
        with torch.no_grad():
            for i, e in enumerate(episodes):
                o_t = torch.tensor(e["s"]["o_task"], dtype=torch.float32).unsqueeze(0)
                a1 = torch.tensor([[e["aux"]]], dtype=torch.float32)
                a2 = torch.tensor([[aux_shuf[i]]], dtype=torch.float32)
                l1, _ = model(o_t, a1)
                l2, _ = model(o_t, a2)
                p1 = torch.softmax(l1.squeeze(0), dim=-1).numpy()
                p2 = torch.softmax(l2.squeeze(0), dim=-1).numpy()
                tvs.append(0.5 * np.abs(p1 - p2).sum())
                if p1.argmax() != p2.argmax():
                    flips += 1
        tv_mean = float(np.mean(tvs))

    return {"return": ret, "own_acc": own_acc, "aux_acc": aux_acc, "tv_mean": tv_mean}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--steps", type=int, default=200_000)
    ap.add_argument("--variants", type=str, default="A,B,C,D,E,H")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--out", type=str, default="v5_4_results.json")
    args = ap.parse_args()

    variants = args.variants.split(",")
    n_seeds = 1 if args.quick else args.seeds
    n_steps = 20_000 if args.quick else args.steps

    print("=" * 70)
    print(f"v5.4 asymmetric two-lock PPO  SIGMA_C={SIGMA_C}")
    print(f"variants={variants}  seeds={n_seeds}  steps={n_steps}")
    print("=" * 70)

    results = defaultdict(lambda: defaultdict(list))
    for variant in variants:
        print(f"\n--- variant {variant} ---")
        for seed in range(n_seeds):
            model = train_variant(variant, seed=seed, n_steps=n_steps)
            ev = eval_variant(model, variant, seed=seed, n_ep=2000)
            for k, v in ev.items():
                if v is not None:
                    results[variant][k].append(v)
            print(f"  {variant} seed={seed}: ret={ev['return']:+.4f}  "
                  f"own_acc={ev['own_acc']:.4f}  aux_acc={ev['aux_acc']}  tv={ev['tv_mean']:.4f}")

    print("\n" + "=" * 70)
    print("SUMMARY (median [min, max])")
    print("=" * 70)
    for variant in variants:
        r = results[variant]["return"]
        tv = results[variant]["tv_mean"]
        if r:
            print(f"  {variant}: ret={np.median(r):+.4f} [{min(r):+.4f},{max(r):+.4f}]   "
                  f"tv={np.median(tv):.4f} [{min(tv):.4f},{max(tv):.4f}]")

    # Preregistered tests
    if "B" in variants and "C" in variants and n_seeds >= 5:
        B = np.array(results["B"]["return"])
        C = np.array(results["C"]["return"])
        D = np.array(results["D"]["return"])
        A = np.array(results["A"]["return"])
        H = np.array(results["H"]["return"])
        E = np.array(results["E"]["return"])
        diff_BC = B - C
        diff_BD = B - D
        diff_BA = B - A
        diff_BH = B - H
        diff_BE = B - E

        print("\n" + "=" * 70)
        print("PREREGISTERED WILCOXON (one-sided, α=0.0125)")
        print("=" * 70)
        for name, d in [("R2: B-C", diff_BC), ("R1: B-D", diff_BD),
                        ("B-A", diff_BA), ("B-H", diff_BH), ("B-E", diff_BE)]:
            try:
                stat, p = wilcoxon(d, alternative="greater")
                print(f"  {name}: median={np.median(d):+.4f}  p={p:.5f}  "
                      f"{'PASS' if p<0.0125 else 'FAIL'}")
            except Exception as ex:
                print(f"  {name}: error {ex}")

        try:
            stat, p = wilcoxon(B - C, alternative="two-sided")
            print(f"  TOST B≈C: |median diff|={abs(np.median(B-C)):.4f}  p={p:.4f}")
        except Exception as ex:
            print(f"  TOST: error {ex}")

    with open(args.out, "w") as f:
        json.dump({v: {k: list(vals) for k, vals in results[v].items()} for v in variants},
                  f, indent=2, default=str)
    print(f"\nSaved: {args.out}")


if __name__ == "__main__":
    main()